# -*- coding: utf-8 -*-
"""
Created on Sat Dec 21 23:44:17 2019
@author: renyu

functionalKeras005_spchCmdNmelSpec.py
ryLab001.py

"""

# In[]

# In[]

import compress_pickle as cpk
import os
import numpy as np

'''        
def get_data_v2(fn= 'spCmdV002_train.gz'):
    
    print('get {} .... '.format(fn))
    
    aL= cpk.load(fn)
    
    xL= []
    yL= []
    for a in aL:
        x, y= a
        xL += [x]
        yL += [y]
    xL= np.concatenate(xL)
    yL= np.concatenate(yL)
    
    cL=  np.array(sorted(list(set(list(yL)))))
    yDist= [list(yL.flatten()).count(c) for c in cL]
    
    
    print('xL.shape= {}\nyL.shape= {}\ncL= {}\nyDist={}'.format(
            xL.shape, yL.shape, cL, yDist))
    
    return xL, yL, cL


data_path= 'spCmdV002_train.gz'
x_train, y_train, c_train= get_data_v2(fn= data_path)

data_path= 'spCmdV002_val.gz'
x_val, y_val, c_val=       get_data_v2(fn= data_path)

data_path= 'spCmdV002_test.gz'
x_test, y_test, c_test=       get_data_v2(fn= data_path)

data_path= 'spCmdV002_testREAL.gz'
x_testREAL, y_testREAL, c_testREAL=       get_data_v2(fn= data_path)
'''

# In[]

# In[]

from ryLab000_PrepareDataset import load_data

fn= 'google_spcmd_test.gz'
[(x_test, y_test, c_test),    (x_testREAL, y_testREAL, c_testREAL)]= load_data(fn)

fn= 'google_spcmd_train.gz'
[(x_train, y_train, c_train), (x_val, y_val, c_val)]= load_data(fn)




# In[]
import tensorflow as tf

def ryFeature(x, 
           sample_rate= 16000, 
           
           frame_length= 1024,
           frame_step=    128,  # frame_length//2
           
           num_mel_bins=     128,
           lower_edge_hertz= 20,     # 0
           upper_edge_hertz= 16000/2, # sample_rate/2   
           
           mfcc_dim= 13
           ):
    
    stfts= tf.signal.stft(x, 
                          frame_length, #=  256, #1024, 
                          frame_step, #=    128,
                          #fft_length= 1024
                          pad_end=True
                          )
    
    spectrograms=     tf.abs(stfts)
    log_spectrograms= tf.math.log(spectrograms + 1e-10)
    
    # Warp the linear scale spectrograms into the mel-scale.
    num_spectrogram_bins= stfts.shape[-1]  #.value
    
    linear_to_mel_weight_matrix= tf.signal.linear_to_mel_weight_matrix(
          num_mel_bins, 
          num_spectrogram_bins, 
          sample_rate, 
          lower_edge_hertz,
          upper_edge_hertz)
    
    mel_spectrograms= tf.tensordot(
          spectrograms, 
          linear_to_mel_weight_matrix, 1)
    
    mel_spectrograms.set_shape(
          spectrograms.shape[:-1].concatenate(
              linear_to_mel_weight_matrix.shape[-1:]))
    
    # Compute a stabilized log to get log-magnitude mel-scale spectrograms.
    log_mel_spectrograms= tf.math.log(mel_spectrograms + 1e-10)
    
    # Compute MFCCs from log_mel_spectrograms and take the first 13.
    mfccs= tf.signal.mfccs_from_log_mel_spectrograms(
          log_mel_spectrograms)[..., :mfcc_dim]
    
    feature= {'mfcc':               mfccs, 
              'log_mel_spectrogram':log_mel_spectrograms, 
              'log_spectrogram':    log_spectrograms, 
              'spectrogram':        spectrograms}
    
    return  feature


batch_size= 1000  # 預防 gpu memory 不夠， 分批作業 
x= x_train[0:batch_size].astype(np.float32)
X= ryFeature(x)['log_mel_spectrogram']
X= X.numpy()

zzz= '''

'''



# In[]

import time

import tensorflow as tf


def get_all_fearure(all_x, batch_size= 1000):
    t0= time.time()
    
    x= all_x.astype(np.float32)
    
    #batch_size= 1000  # 預防 gpu memory 不夠， 分批作業 
    
    i=0
    XL=[]
    while i < x.shape[0]:
        
        if i+batch_size<=x.shape[0]:
            xx= x[i:i+batch_size]
        else:
            xx= x[i:]
        
        XX= ryFeature(xx)
        X= XX['log_mel_spectrogram'] 
        #'log_spectrogram'] #'mfcc'] #'log_mel_spectrogram']
        
        X= X.numpy().astype(np.float32)
        
        i  += batch_size
        XL += [X]
    
    XL= np.concatenate(XL)
    print('XL.shape={}'.format(XL.shape))
    
    dt= time.time()-t0
    print('tf.signal.stft, 執行時間 dt= {}'.format(dt))
    
    '''
    XL.shape=(64721, 125, 129) # nTime= 16000/128, nFreq=256/2+1
    tf.signal.stft, dt= 8.066392660140991
    '''
    return XL

X_testREAL= get_all_fearure(x_testREAL)
X_test=     get_all_fearure(x_test)
X_val=      get_all_fearure(x_val)
X_train=    get_all_fearure(x_train)


# In[]

nTime, nFreq= X_train[0].shape

zzz='''
nTime, nFreq= (125, 128)
'''

# In[]
def normalize(x):   
    x= (x-x.mean())/x.std()
    return x


X_train= X_train.reshape(-1, nTime, nFreq, 1).astype('float32') 
X_val=   X_val.reshape(-1, nTime, nFreq, 1).astype('float32') 
X_test=  X_test.reshape( -1, nTime, nFreq, 1).astype('float32') 
X_testREAL=  X_testREAL.reshape( -1, nTime, nFreq, 1).astype('float32') 

X_train=     normalize(X_train)
X_val=       normalize(X_val)
X_test=      normalize(X_test)
X_testREAL=  normalize(X_testREAL)


# In[]

import tensorflow as tf

tf.keras.backend.clear_session()  
# For easy reset of notebook state.

from tensorflow              import keras
from tensorflow.keras        import layers, Model
from tensorflow.keras.layers import Input, Conv1D, MaxPooling1D, Flatten, Dense, Dropout
from tensorflow.keras.layers import Conv2D, MaxPooling2D
from tensorflow.keras.layers import AveragePooling1D

from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint

# In[]

nCategs= c_train.size #36


x= Input(shape= (nTime, nFreq, 1))

h= x


#'''
h= Conv2D(8,   (16,16), activation='relu', padding='same')(h)
h= MaxPooling2D((4,4), padding='same')(h)
h= Dropout(0.2)(h)

h= Conv2D(16,   (8,8), activation='relu', padding='same')(h)
h= MaxPooling2D((4,4), padding='same')(h)
h= Dropout(0.2)(h)

h= Flatten()(h)

h= Dense(256,  activation='relu')(h)
h= Dropout(0.2)(h)


h= Dense(nCategs,  activation='softmax')(h)

y= h

m= Model(inputs=  x, 
         outputs= y)

m.summary()



# In[]
#keras.utils.plot_model(m, 'm.png', show_shapes=True)



# In[]
m.compile(  
        loss=    'sparse_categorical_crossentropy',
        metrics= ['accuracy'])


es= EarlyStopping(
        monitor=   'val_loss', 
        min_delta= 1e-10,
        patience=  10, 
        mode=      'min', 
        verbose=   1) 

mc= ModelCheckpoint('ry_best_model.hdf5', 
        monitor=    'val_accuracy', 
        verbose=    1, 
        save_best_only= True, 
        mode=      'max')

h= m.fit(X_train, y_train,
         
        batch_size=1000,
        epochs=    100,
        
        callbacks=[es, mc],
        
        #validation_split= 0.1
        validation_data= (X_val, y_val)
        )

# In[]
import numpy as np
from matplotlib import pyplot as pl
v0= h.history['accuracy']
v1= h.history['val_accuracy']
pl.plot(v0, label='accuracy')
pl.plot(v1, label='val_accuracy')
pl.legend()
pl.grid('on')
pl.show()
#keras.utils.plot_model(m, 'm.png', show_shapes=True)

# In[]

m.evaluate(X_test, y_test, verbose=2)
m.evaluate(X_testREAL, y_testREAL, verbose=2)

zzz='''
Epoch 49/100
83968/84736 [============================>.] - ETA: 0s - loss: 0.3737 - accuracy: 0.8813
Epoch 00049: val_accuracy did not improve from 【0.90919】
84736/84736 [==============================] - 8s 93us/sample - loss: 0.3739 - accuracy: 0.8812 - val_loss: 0.3101 - val_accuracy: 0.9068
Epoch 00049: early stopping

11005/1 - 1s - loss: 0.4222 - accuracy: 【0.8964】
4890/1 - 1s - loss: 46.2492 - accuracy: 【0.7348】 !!!!
 ~~~ simulation session ended ~~~
'''

zzz='''
Epoch 46/100
84000/84736 [============================>.] - ETA: 0s - loss: 0.2507 - accuracy: 0.9196 
Epoch 00046: val_accuracy improved from 0.91508 to 0.91589, saving model to 【ry_best_model.hdf5】
84736/84736 [==============================] - 11s 133us/sample - loss: 0.2507 - accuracy: 0.9196 - val_loss: 0.3050 - val_accuracy: 0.9159
Epoch 47/100
84000/84736 [============================>.] - ETA: 0s - loss: 0.2525 - accuracy: 0.9187 
Epoch 00047: val_accuracy did not improve from 【0.91589】
84736/84736 [==============================] - 11s 133us/sample - loss: 0.2528 - accuracy: 0.9185 - val_loss: 0.3070 - val_accuracy: 0.9128
Epoch 00047: early stopping

11005/1 - 2s - loss: 0.4620 - accuracy: 【0.9070】
4890/1 - 1s - loss: 53.1950 - accuracy: 【0.8084】
'''


# In[]

## for version.002
'''
labels= np.array([
        '_silence_', 
        'nine', 
        'yes', 
        'no', 
        'up', 
        'down', 
        'left', 
        'right',
        'on', 
        'off', 
        'stop', 
        'go', 
        'zero', 
        'one', 
        'two', 
        'three', 
        'four',
        'five', 
        'six', 
        'seven', 
        'eight', 
        'backward', 
        'bed', 
        'bird', 
        'cat',
        'dog', 
        'follow', 
        'forward', 
        'happy', 
        'house', 
        'learn', 
        'marvin',
        'sheila', 
        'tree', 
        'visual', 
        'wow'], 
        dtype='<U11')

'''

print(' ~~~ simulation session ended ~~~')

# In[]
import numpy as np
from tensorflow.keras.models import load_model
import sounddevice as sd

labels= np.array([
        '_silence_', 
        'nine', 
        'yes', 
        'no', 
        'up', 
        'down', 
        'left', 
        'right',
        'on', 
        'off', 
        'stop', 
        'go', 
        'zero', 
        'one', 
        'two', 
        'three', 
        'four',
        'five', 
        'six', 
        'seven', 
        'eight', 
        'backward', 
        'bed', 
        'bird', 
        'cat',
        'dog', 
        'follow', 
        'forward', 
        'happy', 
        'house', 
        'learn', 
        'marvin',
        'sheila', 
        'tree', 
        'visual', 
        'wow'], 
        dtype='<U11')


model= load_model('ry_best_model.hdf5')


def predict(audio, fs=16000):
    prob= model.predict(audio)#.reshape(1,fs,1))
    index= np.argmax(prob[0])
    return labels[index]
    
T=  1     # Duration of recording
fs= 16000  # Sample rate

xL= []
for i in range(100):
    
    aKey= input('{}\n{}\n'.format(
                'press "q" to quit', 
                'or another key to record 1 sec speech...'))
    if aKey=='q':
        print('~~~the end~~~')
        break
    
    x= sd.rec(int(T*fs), 
            samplerate= fs, 
            channels= 1, 
            dtype='float32')
        
    sd.wait()  # Wait until recording is finished

    x= x.flatten()
    
    X= ryFeature(x)['log_mel_spectrogram']
    
    X= X.numpy().astype(np.float32)
    
    X= normalize(X)

    X= X.reshape(1,X.shape[0],X.shape[1], 1)
    y= predict(X)
    
    print('y= 【{}】'.format(y))
    xL += [x]
# In[]
import pickle

fn='rySp_v2.gz'
cpk.dump(xL, fn)
xL= cpk.load(fn)


# In[]
    
#import numpy as np
#from tensorflow.keras.models import load_model
import sounddevice as sd

import pylab as pl    
for x in xL:
        
    sd.play(x, samplerate= 16000)
    pl.plot(x)
    pl.show()
    
    X= ryFeature(x)['log_mel_spectrogram']
    
    X= X.numpy().astype(np.float32)
    
    
    X= normalize(X)

    Xspec= X.reshape(X.shape[0],X.shape[1])
    pl.imshow(Xspec.transpose(), origin='low')
    pl.show()


    Xin= X.reshape(1,X.shape[0],X.shape[1], 1)
    y= predict(Xin)
    print('y= 【{}】'.format(y))
        
    sd.wait()
    
# In[]
print('... ry: Good Luck ...')










































